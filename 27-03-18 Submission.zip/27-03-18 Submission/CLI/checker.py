from cmd import *

print (cmd.*)